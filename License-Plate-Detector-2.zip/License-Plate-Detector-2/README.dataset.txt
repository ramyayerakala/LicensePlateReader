# License Plate Detector > 2023-08-31 10:01am
https://universe.roboflow.com/snu-i6ovv/license-plate-detector-ogxxg

Provided by a Roboflow user
License: CC BY 4.0

